/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop_inheritance;

/**
 *
 * @author User
 */
public class Person {
    String fname;
    String lname;
    
    
    public void showdetails()
    {
    System.out.println("First name :"+fname);
    System.out.println("Last name :"+lname);
    }
    

    
}
