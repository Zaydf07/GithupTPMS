/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop_inheritance;

/**
 *
 * @author User
 */
public class Student extends Person{
    int classyear;
    
    
    public void showdetails()
    {
    System.out.println("Class year :"+classyear);
    }
    
}
