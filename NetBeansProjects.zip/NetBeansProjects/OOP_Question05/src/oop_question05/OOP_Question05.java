/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop_question05;

/**
 *
 * @author User
 */
public class OOP_Question05 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Circle c1=new Circle();
        
        
        c1.setX(3.21);
        c1.setY(2.22);
        c1.setR(4.55);
        
        System.out.println("Cir:"+c1.calculateCircumference());
        
        System.out.println("Area:"+c1.calculateArea());
    }
    
}
