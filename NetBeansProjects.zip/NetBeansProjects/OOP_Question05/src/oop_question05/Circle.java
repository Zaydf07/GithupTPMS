/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop_question05;

/**
 *
 * @author User
 */
public class Circle {
    private double x,y;
    private double r;
    
    public void setX(double coordinateX)
    {
    x=coordinateX;
    }
    
    public double getX ()
    {
    return x;
    }
    
    
    public void setY(double coordinateY)
    {
    y=coordinateY;
    }
    
      public double getY ()
    {
    return y;
    }
    
    public void setR(double radius)
    {
    r=radius;
    }
      
      public double getR ()
    {
    return r;
    }
      
      public double calculateCircumference()
      {
      return 2*3.1459*r;
      }
      
      public double calculateArea()
      {
      return 3.1459*r*r;
      }
    
    
}
