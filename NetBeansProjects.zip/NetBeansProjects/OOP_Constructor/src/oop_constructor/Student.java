/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop_constructor;

/**
 *
 * @author User
 */
public class Student {
    
    String name;
    String address;
    
    public Student (String sname, String saddress)
    {
    this.name=sname;
    this.address=saddress;
          
    }
    
    
      public Student ()
    {
   
    }
    
      
      public Student (String sname)
    {
    this.name=sname;
          
    }
    public void showdetails()
    {
    System.out.println("Name :"+name);
    System.out.println("Address :"+address);
    }
    
}
