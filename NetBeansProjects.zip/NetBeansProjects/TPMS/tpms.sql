-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 04, 2022 at 03:00 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tpms`
--

-- --------------------------------------------------------

--
-- Table structure for table `crop`
--

CREATE TABLE `crop` (
  `crop_id` int(255) DEFAULT NULL,
  `crop_name` varchar(255) DEFAULT NULL,
  `crop_amount` int(255) DEFAULT NULL,
  `plant_date` varchar(255) DEFAULT NULL,
  `harvest_date` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `crop`
--

INSERT INTO `crop` (`crop_id`, `crop_name`, `crop_amount`, `plant_date`, `harvest_date`) VALUES
(111, 'eefr', 111, '122', '221'),
(22, 'eergf', 33, '2022', '2022'),
(111, '223', 212, '12', '12');

-- --------------------------------------------------------

--
-- Table structure for table `distribution`
--

CREATE TABLE `distribution` (
  `inventory_id` int(255) DEFAULT NULL,
  `fertilizer_id` int(255) DEFAULT NULL,
  `fertilizer_name` varchar(255) DEFAULT NULL,
  `fert_amount` int(255) DEFAULT NULL,
  `dist_date` int(255) DEFAULT NULL,
  `received_date` int(255) DEFAULT NULL,
  `uorn` varchar(255) DEFAULT NULL,
  `plant_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `do_foreg`
--

CREATE TABLE `do_foreg` (
  `nic` varchar(255) DEFAULT NULL,
  `fname` varchar(255) DEFAULT NULL,
  `lname` varchar(255) DEFAULT NULL,
  `uorn` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `do_foreg`
--

INSERT INTO `do_foreg` (`nic`, `fname`, `lname`, `uorn`) VALUES
('1111', 'fff', 'hhhh', '54321'),
('5555', 'ddd', 'gggg', '76544'),
('7777', 'John', 'Cena', '9876'),
('2000445', 'clark ', 'keny', '4444');

-- --------------------------------------------------------

--
-- Table structure for table `do_login`
--

CREATE TABLE `do_login` (
  `uname` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `fertilizer`
--

CREATE TABLE `fertilizer` (
  `fertilizer_id` int(255) DEFAULT NULL,
  `fertilizer_name` varchar(255) DEFAULT NULL,
  `fertilizer_amount` int(255) DEFAULT NULL,
  `received_date` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fertilizer`
--

INSERT INTO `fertilizer` (`fertilizer_id`, `fertilizer_name`, `fertilizer_amount`, `received_date`) VALUES
(111, 'adfff', 121, '122'),
(544, '1234', 33, '2022'),
(22, 'ewdew', 1000, 'weew');

-- --------------------------------------------------------

--
-- Table structure for table `fo_login`
--

CREATE TABLE `fo_login` (
  `nic` int(255) DEFAULT NULL,
  `uorn` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fo_login`
--

INSERT INTO `fo_login` (`nic`, `uorn`) VALUES
(1234, '1111'),
(2222, '');

-- --------------------------------------------------------

--
-- Table structure for table `gm_login`
--

CREATE TABLE `gm_login` (
  `uname` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `gm_login`
--

INSERT INTO `gm_login` (`uname`, `password`) VALUES
('', ''),
('', ''),
('ssss', '22222');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `inventory_id` varchar(255) NOT NULL,
  `inventory_name` varchar(255) DEFAULT NULL,
  `fert_id` varchar(255) DEFAULT NULL,
  `fert_name` varchar(255) DEFAULT NULL,
  `district` varchar(255) DEFAULT NULL,
  `fert_amount` varchar(255) DEFAULT NULL,
  `distribution_date` varchar(255) DEFAULT NULL,
  `refill_date` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`inventory_id`, `inventory_name`, `fert_id`, `fert_name`, `district`, `fert_amount`, `distribution_date`, `refill_date`) VALUES
('111', 'aadd', '3333', 'ddfg', 'kandy', '200', '2022', '2022'),
('11111', 'rrrrr', '22222', 'ddddd', 'kandy', '1000', NULL, '2022'),
('5555', 'gbgfbh', '333', 'gfjhg', 'dddd', '1000', '15/12/22', '12/12/22');

-- --------------------------------------------------------

--
-- Table structure for table `plantation`
--

CREATE TABLE `plantation` (
  `plantation_id` varchar(255) DEFAULT NULL,
  `plantation_name` varchar(255) DEFAULT NULL,
  `district_name` varchar(255) DEFAULT NULL,
  `planter` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `plantation`
--

INSERT INTO `plantation` (`plantation_id`, `plantation_name`, `district_name`, `planter`, `date`) VALUES
('qqwqqwe', '1111', 'kandy', NULL, NULL),
('ggggg', '12', 'hhhh', NULL, NULL),
('', '', '', NULL, NULL),
('12e2e3', '3e3r', 'wedfrf', 'dfcd', 'fddg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `nic` varchar(255) DEFAULT NULL,
  `fname` varchar(255) DEFAULT NULL,
  `lname` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone` int(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`nic`, `fname`, `lname`, `address`, `phone`) VALUES
('1234', 'aaaa', 'sssss', 'assdff', 304405),
('333333', 'ggggg', 'hhhhh', 'nnnnnn', 324456643),
('7654', 'zayd', 'faisal', 'Kandy', 11111),
('444', 'bruce', 'wayne', 'gotham', 776655),
('11111', '1111', 'dfghh', 'wefert', 484733);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`inventory_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
