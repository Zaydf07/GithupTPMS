/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question03;

/**
 *
 * @author User
 */
public class Person {
    String Name;
    int Othrs;
    int Otrate;
    int basicsalary;
    int netsalary;
    
    
    public void show()
    {
    System.out.println("Name:"+Name);
    }
    public double calc_amount()
    {
    double otamount= Othrs*Otrate;
    return otamount;
    }
    
   public double calc_netsalary(double otamount)
   {
   double netsalary= otamount +basicsalary;
   return netsalary;
   }

}
