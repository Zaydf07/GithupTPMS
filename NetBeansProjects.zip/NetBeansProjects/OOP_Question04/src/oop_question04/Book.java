/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop_question04;

/**
 *
 * @author User
 */
public class Book {
    
    private String name;
    private String author;
    private String ISBN;
    
    
    public void setname(String name)
    {
    this.name=name;
    }
    
    public String getname()
    {
    return this.name;
    }
    
    
     public void setauthor(String author)
    {
    this.author=author;
    }
    
    public String getauthor()
    {
    return this.author;
    }
    
     public void setISBN(String ISBN)
    {
    this.ISBN=ISBN;
    }
    
    public String getISBN()
    {
    return this.ISBN;
    }
    public void showDetails()
    {
    System.out.println("Book Name :"+name);
    System.out.println("Author :"+author);
    System.out.println("ISBN :"+ISBN);
    }
    
}
