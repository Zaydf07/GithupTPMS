/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop_question02;

/**
 *
 * @author User
 */
public class Bank {
    String acc_number;
    String acc_name;
    double acc_balance;
    
    
    public void show()
    {
     System.out.println("Number:"+acc_number);
    System.out.println("Name :"+acc_name);
    }
    
    
    public void show_balance()
    {
   
    System.out.println("Balance :"+acc_balance);
    }
    
    public void deposit(double amount)
    {
    acc_balance=acc_balance+amount;
    }
    
    public void withdraw (double amount)
    {
    acc_balance=acc_balance-amount;
    }
    
}
