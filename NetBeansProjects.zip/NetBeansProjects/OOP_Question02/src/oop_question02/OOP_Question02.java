/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop_question02;

/**
 *
 * @author User
 */
public class OOP_Question02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Bank b1=new Bank();
        
        b1.acc_number="B01";
        b1.acc_name="Zayd";
        b1.acc_balance=1000.00;
        
        b1.show();
        b1.deposit(1000);
        b1.withdraw(500);
        b1.show_balance();
    }
    
}
