/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop_question01;

/**
 *
 * @author User
 */
public class OOP_Question01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Student s1=new Student();
        
        s1.student_nic="200000v";
        s1.student_name="Zayd";
        s1.student_address="Kandy";
        
        s1.show();
        
        Student s2=new Student();
        
        s2.student_nic="2000001v";
        s2.student_name="Anne";
        s2.student_address="Colombo";
        
        s2.show();
    }
    
}
