/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop_question01;

/**
 *
 * @author User
 */
public class Student {
    
    String student_nic;
    String student_name;
    String student_address;
    
    
    public void show()
    {
        System.out.println("NIC :"+student_nic);
        System.out.println("Name :"+student_name);
        System.out.println("Address :"+student_address);


    }
}
